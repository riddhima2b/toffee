import axios from "axios";
import { React, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
const Login = () => {

  const navigate=useNavigate();
    const [Values,setValues]=useState({
    email:"",
    password:"",
    });
    const change=(e)=>{
    const{name,value}=e.target;
    setValues({...Values,[name]:value});
    };
    console.log(Values);
    const login=async(e)=>
    {
    e.preventDefault();
    try{
      const res= await axios.post("http://localhost:3001/api/v1/login",Values,
        {
          withCredentials:true,
          
        }
        
      );alert(res.data.success)
      localStorage.setItem("token", res.data.token);
      
      console.log(res.data);
      localStorage.setItem("userLoggedIn","yes");

      console.log(res.data.success);
      navigate("/Dashboard");
      //setEditTaskDiv("hidden");
      console.log(res.data);
    }
    
    catch(error)
    {
      console.log(error.response.data);
    }
    
  };
  return (
    <>
    <div className='flex min-h-screen flex-col items-center justify-center  bg-cyan-50'>
    <div className='w-[90vw] md:w-[50vw] lg:w-[30vw] bg-white p-6 rounded-lg shadow-md'>

    <h1 className='text-3xl font-bold font-serif text-center mb-1 text-pink-500  px-6 py-3'>
      WELCOME TO TOFFEE!
      </h1><>&nbsp;</>
      
    <div>
    <h3 className='text-center font-semibold text-black-900 text-xl mb-4'>
      Login
    </h3>
    
    <form className='flex flex-col gap-4'>
    
      <input
        type="email" 
        
        required
        placeholder="Email"
        className="border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
        name="email" 
        value={Values.email}
        onChange={change}
      />
      <input
        type="password" required
        placeholder="Password"
        className="border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
        name="password"
        value={Values.password}
        onChange={change}
      />
      <button className='bg-blue-500 text-white rounded-md py-2 hover:bg-blue-600'onClick={login}>
        Login
      </button>
      <p className=' text-center justify-center'>
        Don&apos;t have an account? <Link to="/register">Sign Up</Link>
      </p>
    </form>
    </div>
    </div>
    </div>

</>
  )
}

export default Login
