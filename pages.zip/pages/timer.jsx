import React, { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";

export default function PomodoroTimer() {
  const [timeLeft, setTimeLeft] = useState(25 * 60);
  const [isRunning, setIsRunning] = useState(false);
  const bell=useRef(null);

  useEffect(() => {
    let timer;
    if (isRunning && timeLeft > 0) {
      timer = setInterval(() => {
        setTimeLeft((prevTime) => prevTime - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      
      setIsRunning(false);
      bell.current?.play();
      alert("Time's up! Take a break.");
    }
    return () => clearInterval(timer);
  }, [isRunning, timeLeft]);

  const formatTime = (seconds) => {
    const minutes = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${minutes.toString().padStart(2, "0")}:${secs
      .toString()
      .padStart(2, "0")}`;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 via-rose-50 to-amber-50 flex flex-col">
      {/* Header */}
      <header className="text-center p-6">
        <h1 className="text-4xl font-extrabold text-pink-500 mb-2 drop-shadow">
          Try Pomodoro! 
        </h1>
        <p className="text-lg text-emerald-600 font-serif font-medium">
          Stay focused. Work smart. Take breaks.
        </p>
      </header>

      {/* Timer Content */}
      <main className="flex-grow flex flex-col items-center justify-center text-center px-4">
        <h2 className="text-2xl font-semi-bold font-serif  text-green-400 mb-4">
          Click on Start and get working!
        </h2>

        <div className="text-7xl font-serif font-bold text-gray-800 bg-white px-10 py-4 rounded-2xl shadow-md mb-6">
          {formatTime(timeLeft)}
        </div>

        <div className="flex gap-4">
          <button
            onClick={() => setIsRunning(!isRunning)}
            className={`px-6 py-2 rounded-full text-white font-semibold transition-all duration-300 ${
              isRunning
                ? "bg-red-500 hover:bg-red-600"
                : "bg-amber-500 hover:bg-amber-600"
            }`}
          >
            {isRunning ? "Pause" : "Start"}
          </button>

          <button
            onClick={() => {
              setIsRunning(false);
              setTimeLeft(25 * 60);
            }}
            className="px-6 py-2 rounded-full bg-gray-300 hover:bg-gray-400 text-gray-800 font-semibold transition-all duration-300"
          >
            Reset
          </button>
        </div>
        
        </main>
        <audio ref={bell} src="/bell.wav" preload="auto">

        </audio>
        <button>
        <Link to="/Dashboard"
        className="mt-6 bg-pink-500 text-white font-semibold py-2 px-4 rounded-xl  transition duration-300">
        Back to Dashboard</Link>
      </button><br></br>
        
     
      <footer className="text-center text-sm text-gray-400 pb-4">
        Stay productive with TOFFEE 🍬
      </footer>
    </div>
  );
}
