import axios from "axios";
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
const Register = () => {

  const navigate=useNavigate();
  const [Values,setValues]=useState({
    username:"",
    email:"",
    password:"",
  });
  const change=(e)=>{
    const{name,value}=e.target;
    setValues({...Values,[name]:value});
  };
  console.log(Values);
  const register=async(e)=>
  {
    e.preventDefault();
    try{
      const res= await axios.post("http://localhost:3001/api/v1/register",Values);
      alert(res.data.success);
      navigate("/Login");
    }
    catch(error)
    {
      alert(error.response.data.error);
    }
  };
  return (<>

    <div className='flex min-h-screen flex-col items-center justify-center bg-cyan-50'>
    <div className='w-[90vw] md:w-[50vw] lg:w-[30vw] bg-white p-6 rounded-lg shadow-md'>
      <h1 className='text-3xl font-bold font-serif text-center text-pink-500  px-6 py-3 '>
      WELCOME TO TOFFEE!
      </h1><>&nbsp;</>
      
    <div>
    <h3 className='text-center font-semibold text-black-900 text-xl mb-4'>
      Register & Sign Up
    </h3>
    
    <form className='flex flex-col gap-4' >
    <input
        type="text" required
        placeholder="username"
        className="border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
        name="username"
        value={Values.username}
        onChange={change}
      />
      <input
        type="email" required
        placeholder="email"
        className="border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
        name="email"
        value={Values.email}
        onChange={change}
      />
      <input
        type="password" required
        placeholder="password"
        className="border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
        name="password"
        value={Values.password}
        onChange={change}
      />
      <button className='bg-blue-500 text-white rounded-md py-2 hover:bg-blue-600'onClick={register}>
        Register
      </button>
      <p className=' text-center justify-center'>
              Already have an account? <Link to="/login">Login</Link>
            </p>
    </form>
    </div>
    </div>
    </div>

</>
  )
};

export default Register;
