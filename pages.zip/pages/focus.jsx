import axios from "axios";
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import Completed from "../components/Completed";
import InProgress from "../components/InProgress";
import StackTitle from "../components/StackTitle";
import YetToStart from "../components/YetToStart";



const FocusMode = () => {
  const [Tasks, setTasks] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchTasks = async () => {
      const token = localStorage.getItem("token");
      try {
        const res = await axios.get("http://localhost:3001/api/v2/getUserDetails", {
          headers: { Authorization: `Bearer ${token}` },
        });
        setTasks(res.data.tasks);
      } catch (err) {
        console.error("Failed to fetch tasks:", err);
      }
    };

    fetchTasks();
  }, []);

  const filterHighPriority = (list) =>
    list?.filter((task) => task.priority === "high");

  const highTodo = filterHighPriority(Tasks?.yetToStart);
  const highProgress = filterHighPriority(Tasks?.inProgress);
  const highComplete = filterHighPriority(Tasks?.completed); // fixed case

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-100 via-white to-blue-200 text-gray-800 p-8">
      {/* Header */}
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-thin font-serif text-blue-700">
           FOCUS Mode — No Distractions, Only Focus.
        </h1>
        <button
          onClick={() => navigate("/dashboard")}
          className="px-4 py-2 rounded-full font-serif font-semibold bg-pink-600 hover:bg-pink-700 text-white transition"
        >
          Exit Focus Mode
        </button>
      </div>

      <p className="text-lg text-gray-700 mb-8 italic">
        Work on your high-priority tasks, one step at a time.
      </p><br>

      </br>
      


      {/* Task columns */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div>
          <StackTitle title="To-Do " />
          <div className="pt-4 space-y-3">
            {Tasks && <YetToStart tasks={highTodo} />}
          </div>
        </div>

        <div>
          <StackTitle title="In Progress " />
          <div className="pt-4 space-y-3">
            {Tasks && <InProgress tasks={highProgress} />}
          </div>
        </div>

        <div>
          <StackTitle title="Completed " />
          <div className="pt-4 space-y-3">
            {Tasks && <Completed tasks={highComplete} />}
          </div>
        </div>
      </div>

    </div>
  );
};

export default FocusMode;
