import React from "react";
import { Link } from "react-router-dom";

const FrontPage = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-100 to-pink-100 flex flex-col items-center justify-center text-center px-4">
      <h1 className="text-5xl font-extrabold text-pink-600 mb-4 drop-shadow-lg">
        Welcome to TOFFEE 
      </h1><br></br>
      <p className="text-lg text-gray-700 mb-8 max-w-md">
      Task Management Simplified. 
      </p>

      <Link to="/register">
        <button className="bg-pink-500 text-white text-lg px-6 py-3 rounded-full shadow-md">
          Get Started
        </button>
      </Link>

      <footer className="mt-16 text-sm text-gray-500">
        Simplifying work with TOFFEE 🍬
      </footer>
    </div>
  );
};

export default FrontPage;
