import React, { useEffect, useState } from 'react';
import { useNavigate } from "react-router-dom";

const dailyChecklistItems = [
  'Drank 8 glasses of water',
  'Took a walk',
  'Exercised',
  'Ate healthy meals',
  'Slept 7+ hours',
  'No junk food',
  'Did breathing/meditation',
];

const HealthMode = () => {
  const [checklist, setChecklist] = useState({});
  const [congratulations, setCongratulations] = useState(false); // To track if user completed all tasks
  const navigate = useNavigate();

  // Load checklist state from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('healthChecklist');
    if (saved) {
      setChecklist(JSON.parse(saved));
    } else {
      const initial = {};
      dailyChecklistItems.forEach(item => (initial[item] = false));
      setChecklist(initial);
    }
  }, []);

  // Check if all items are completed
  useEffect(() => {
    const allCompleted = Object.values(checklist).every(value => value === true);
    setCongratulations(allCompleted);
  }, [checklist]);

  const toggleItem = (item) => {
    const updated = { ...checklist, [item]: !checklist[item] };
    setChecklist(updated);
    localStorage.setItem('healthChecklist', JSON.stringify(updated));
  };

  // Reset all checklist items to false
  const resetChecklist = () => {
    const reset = {};
    dailyChecklistItems.forEach(item => (reset[item] = false));
    setChecklist(reset);
    localStorage.setItem('healthChecklist', JSON.stringify(reset));
  };

  return (
    <div className="min-h-screen bg-pink-50 from-green-100 via-white to-green-200 p-8">
      <h1 className="text-4xl font-serif font-semibold text-center text-green-700 mb-8">
        Health Mode – Just You & Your Wellness
      </h1>

      <div className="max-w-xl mx-auto bg-white rounded-2xl shadow-md p-6 space-y-6">
        {dailyChecklistItems.map((item) => (
          <label
            key={item}
            className={`flex items-center space-x-4 font-serif cursor-pointer p-3 rounded-lg transition ${
              checklist[item]
                ? 'bg-green-100 text-green-700 line-through'
                : 'hover:bg-green-50'
            }`}
          >
            <input
              type="checkbox"
              checked={checklist[item] || false}
              onChange={() => toggleItem(item)}
              className="h-5 w-5 text-green-500 accent-green-600"
            />
            <span className="text-lg">{item}</span>
          </label>
        ))}

        {/* Congratulatory Message */}
        {congratulations && (
          <div className="mt-6 text-center p-4 bg-green-100 rounded-lg text-green-700">
            <h2 className="text-2xl font-semibold">Congratulations!</h2>
            <p>You have completed all your wellness tasks for today!</p>
          </div>
        )}
      </div>

      {/* Reset Button */}
      <div className="mt-8 flex font-serif justify-center">
        <button
          onClick={resetChecklist}
          className="px-6 py-3 rounded-full bg-yellow-500 hover:bg-yellow-600 text-white transition mr-4"
        >
          Reset Checklist
        </button>

        {/* Exit Button */}
        <button
          onClick={() => navigate("/dashboard")}
          className="px-6 py-3 rounded-full bg-pink-600 hover:bg-pink-700 text-white transition"
        >
          Exit Health & Wellness Mode
        </button>
      </div>
    </div>
  );
};

export default HealthMode;
