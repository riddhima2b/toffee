import "@fullcalendar/common/index.css";
import dayGridPlugin from "@fullcalendar/daygrid";
//import "@fullcalendar/daygrid/index.css";
import FullCalendar from "@fullcalendar/react";
import timeGridPlugin from "@fullcalendar/timegrid";
//import "@fullcalendar/timegrid/index.css";

const CalendarPage = ({ tasks }) => {
  const events = tasks.map(task => ({
    title: task.title,
    start: task.dueDate,
    allDay: true,
    backgroundColor: task.completed ? "#16a34a" : "#dc2626",
  }));

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">📅 Task Calendar</h1>
      <FullCalendar
        plugins={[dayGridPlugin, timeGridPlugin]}
        initialView="dayGridMonth"
        events={events}
        height="auto"
      />
    </div>
  );
};

export default CalendarPage;
