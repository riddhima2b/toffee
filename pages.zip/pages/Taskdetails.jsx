import React from 'react'

const Taskdetails = () => {
  return (
    <div>
      TaskDetails
    </div>
  )
}

export default Taskdetails
