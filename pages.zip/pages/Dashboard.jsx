import axios from "axios";
import React, { useEffect, useState } from "react";
import AddTask from "../components/AddTask.jsx";
import Completed from "../components/Completed.jsx";
import EditTask from "../components/EditTask.jsx";
import Header from "../components/Header.jsx";
import InProgress from "../components/InProgress.jsx";
import StackTitle from "../components/StackTitle.jsx";
import YetToStart from "../components/YetToStart.jsx";

const Dashboard = () => {
  const [AddTaskDiv, setAddTaskDiv] = useState("hidden");
  const [Tasks, setTasks] = useState([]);
  const [editTaskDiv, setEditTaskDiv] = useState("hidden");
  const [EditTaskId, setEditTaskId] = useState();
  const [dueTodayTasks, setDueTodayTasks] = useState([]); // tasks due today
  const [showPopup, setShowPopup] = useState(false); // Initially set to false

  useEffect(() => {
    const fetUserDetails = async () => {
      const token = localStorage.getItem("token");
      try {
        const res = await axios.get("http://localhost:3001/api/v2/getUserDetails", {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
  
        setTasks(res.data.tasks);
  
        // function to format dates into "YYYY-MM-DD"
        const formatDateToYMD = (dateString) => {
          const [day, month, year] = dateString.split('/');
          return `${year}-${month}-${day}`;
        };
  
        // Get today's date in "YYYY-MM-DD" format
        const today = new Date().toISOString().split('T')[0];
  
        // Combine all tasks
        const allTasks = [
          ...(res.data.tasks.yetToStart || []),
          ...(res.data.tasks.inProgress || []),
          ...(res.data.tasks.completed || [])
        ];
  
        // Filter tasks due today
        const tasksDueToday = allTasks.filter(task => {
          const taskDue = formatDateToYMD(task.dueDate); 
          return taskDue === today;
        });
  
        setDueTodayTasks(tasksDueToday); // Set tasks due today
  
        // Show pop-up if tasks are due today
        if (tasksDueToday.length > 0) {
          setShowPopup(true); // Show the pop-up if there are due tasks
        }
  
      } catch (error) {
        console.error("Error fetching tasks:", error);
      }
    };
  
    fetUserDetails();
  
    setEditTaskDiv("hidden");
    if (window.sessionStorage.getItem("editTaskId")) {
      setEditTaskDiv("block");
      setEditTaskId(window.sessionStorage.getItem("editTaskId"));
      window.sessionStorage.removeItem("editTaskId");
    }
  }, []);
  
  // Sort tasks based on priority
  const sortByPriority = (taskList) => {
    if (!taskList) return [];

    return [...taskList].sort((a, b) => {
      if (a.priority === b.priority) return 0;
      if (a.priority === "high") return -1;
      if (b.priority === "high") return 1;
      if (a.priority === "medium") return -1;
      if (b.priority === "medium") return 1;
      return 0;
    });
  };

  const sortedYetToStart = sortByPriority(Tasks?.yetToStart);
  const sortedInProgress = sortByPriority(Tasks?.inProgress);
  const sortedCompleted = sortByPriority(Tasks?.completed);
  const totalTasks = (Tasks?.yetToStart?.length || 0) + (Tasks?.inProgress?.length || 0) + (Tasks?.completed?.length || 0);
  const completedTasks = Tasks?.completed?.length || 0;
  const progress = totalTasks ? Math.round((completedTasks / totalTasks) * 100) : 0;

  const today = new Date().toLocaleDateString("en-GB", {
    weekday: "long",
    day: "2-digit",
    month: "long",
    year: "numeric",
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-100 via-white to-pink-200">
      {/* Header */}
      <div className="w-full sticky top-0 bg-pink-100 shadow-sm z-10">
        <Header setAddTaskDiv={setAddTaskDiv} />
      </div>

      <div className="py-4 text-center border-pink-200">
        <div className="py-2 text-xl font-bold text-orange-700 font-serif">
          🗓️ {today}
        </div>
      </div>

      {/* Progress Bar */}
      <div className="w-full bg-pink-50 px-12 py-4 space-y-2 flex items-center justify-between border-b border-pink-200">
        <div className="flex-2 mx-10 border-pink-200">
          <div className="text-pink-50 border-pink-200">------</div>
          <div className="w-full bg-cyan-100 rounded-full h-4 overflow-hidden">
            <div className="bg-pink-500 h-full transition-all duration-300" style={{ width: `${progress}%` }} />
          </div>
          {progress === 100 ? (
            <div className="text-center text-green-600 font-semibold italic">
              Yay! No more tasks for today!
            </div>
          ) : (
            <div className="flex justify-between items-center text-sm font-medium text-rose-600">
              <span>{progress}% done</span>
              <span className="italic">You&apos;re doing great! Keep up!</span>
            </div>
          )}
        </div>
      </div>

      {/* Pop-up for Tasks Due Today */}
      {showPopup && dueTodayTasks.length > 0 && (
        <div className="fixed top-0 left-0 w-full h-full bg-black bg-opacity-50 flex items-center justify-center z-20">
          <div className="bg-white p-6 rounded-xl w-1/3 shadow-lg transition-all">
            <h2 className="text-xl font-bold text-red-600">⚠️ Tasks Due Today!</h2>
            <ul className="mt-4 space-y-2">
              {dueTodayTasks.map((task, index) => (
                <li key={index} className="text-lg text-gray-700">
                  {task.title}
                </li>
              ))}
            </ul>
            <button
              className="mt-4 px-4 py-2 bg-red-600 text-white rounded-full"
              onClick={() => setShowPopup(false)}
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* Task Columns */}
      <div className="px-12 py-6 flex gap-8 min-h-[85vh]">
        <div className="w-1/3">
          <StackTitle title={"To-Do"} />
          <div className="pt-4 space-y-3">
            {Tasks && <YetToStart tasks={sortedYetToStart} />}
          </div>
        </div>

        <div className="w-1/3">
          <StackTitle title={"Work In Progress"} />
          <div className="pt-4 space-y-3">
            {Tasks && <InProgress tasks={sortedInProgress} />}
          </div>
        </div>

        <div className="w-1/3">
          <StackTitle title={"Completed"} />
          <div className="pt-4 space-y-3">
            {Tasks && <Completed tasks={sortedCompleted} />}
          </div>
        </div>
      </div>

      {/* Overlay for Add Task */}
      <div className={`w-full ${AddTaskDiv} fixed top-0 left-0 h-screen bg-black bg-opacity-40`}></div>
      <div className={`w-full ${AddTaskDiv} h-screen fixed top-0 left-0 flex items-center justify-center`}>
        <AddTask setAddTaskDiv={setAddTaskDiv} />
      </div>

      {/* Overlay for Edit Task */}
      <div className={`w-full ${editTaskDiv} fixed top-0 left-0 h-screen bg-black bg-opacity-40`}></div>
      <div className={`w-full ${editTaskDiv} h-screen fixed top-0 left-0 flex items-center justify-center`}>
        <EditTask EditTaskId={EditTaskId} setEditTaskDiv={setEditTaskDiv} />
      </div>

      {/* Footer */}
      <footer className="text-center font-serif text-sm text-gray-500 pb-4">
        Stay productive with <span className="font-bold text-grey-500">TOFFEE</span>
      </footer>
    </div>
  );
};

export default Dashboard;
