import React from 'react'

const StackTitle = ({title}) => {
  return (
    <div className="border-b pb-5">
    <h1 className="font-semibold text-blue-500 text-center font-serif text-2xl">{title}</h1>
      
    </div>
  )
}

export default StackTitle
