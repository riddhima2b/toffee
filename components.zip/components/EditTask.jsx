import axios from 'axios';
import React, { useEffect, useState } from 'react';

const EditTask = ({setEditTaskDiv,EditTaskId}) => {

    const [Values, setValues] = useState({
        title: "",
        description: "",
        priority: "low",
        status: "yetToStart",
      });
    
      const change = (e) => {
        const { name, value } = e.target;
        setValues({ ...Values, [name]: value });
      };
      console.log(EditTaskId);
      useEffect(() => {
        const fetch = async () => {
            const token = localStorage.getItem("token");

          try {
            const res = await axios.get(
              `http://localhost:3001/api/v2/getTask/${EditTaskId}`,
                {
                    headers: {
                        Authorization: `Bearer ${token}`,
                      },
                      
                        //withCredentials:true,
                      
                }
    
            );
            setValues(res.data.taskDetails);
            //window.location.reload();
            //setEditTaskDiv("hidden");
          } catch (error) {
            console.log(error);
          }
        };fetch();
      }, [EditTaskId]);
      
      const editTask = async (e,id) => {
        const token = localStorage.getItem("token");
        console.log(token);
        e.preventDefault();
        try {
          const res = await axios.put(`http://localhost:3001/api/v2/editTask/${EditTaskId}`,Values , {
            headers: {
                Authorization: `Bearer ${token}`
            }
          });
          alert(res.data.success);
          setEditTaskDiv("hidden");
          window.sessionStorage.clear("EditTaskId")
          setEditTaskDiv("hidden");
          
          window.location.reload();
          //console.log(res.data);
          //alert("Task added successfully!");
        } catch (error) {
          alert(error.response.data.error);
        }
      };

      const deleteTask = async (e,id) => {
        const token = localStorage.getItem("token");
        console.log(token);
        e.preventDefault();
        try {
          const res = await axios.delete(`http://localhost:3001/api/v2/deleteTask/${EditTaskId}`, {
            headers: {
                Authorization: `Bearer ${token}`
            }
          });
          alert(res.data.success);
          setEditTaskDiv("hidden");
          window.sessionStorage.clear("EditTaskId")
          window.location.reload();
          //console.log(res.data);
          //alert("Task added successfully!");
        } catch (error) {
          alert(error.response.data.error);
        }
      };

    return (
      <div className="fixed top-23 bg-white rounded-2xl shadow-lg px-6 py-6 w-full max-w-xl mx-auto font-serif">
      <h1 className="text-center font-bold text-2xl text-pink-500 mb-2">Edit Task</h1>
      <hr className="mb-6 border-pink-200" />
    
      <form className="flex flex-col gap-5">
        {/* Title */}
        <div>
          <label htmlFor="title" className="block text-sm font-medium mb-1 text-gray-700">
            Task Title
          </label>
          <input
            type="text"
            id="title"
            name="title"
            value={Values.title}
            onChange={change}
            placeholder="Enter task title"
            className="w-full px-4 py-2 rounded-lg border border-gray-300 bg-pink-50 focus:outline-none focus:ring-2 focus:ring-pink-300"
            required
          />
        </div>
    
        {/* Status */}
        <div>
          <label htmlFor="status" className="block text-sm font-medium mb-1 text-gray-700">
            Status
          </label>
          <select
            id="status"
            name="status"
            value={Values.status}
            onChange={change}
            className="w-full px-4 py-2 rounded-lg border border-gray-300 bg-pink-50 focus:outline-none focus:ring-2 focus:ring-pink-300"
            required
          >
            <option value="yetToStart">Pending</option>
            <option value="inProgress">Ongoing</option>
            <option value="Completed">Completed</option>
          </select>
        </div>
    
        {/* Priority */}
        <div>
          <label htmlFor="priority" className="block text-sm font-medium mb-1 text-gray-700">
            Priority
          </label>
          <select
            id="priority"
            name="priority"
            value={Values.priority}
            onChange={change}
            className="w-full px-4 py-2 rounded-lg border border-gray-300 bg-pink-50 focus:outline-none focus:ring-2 focus:ring-pink-300"
            required
          >
            <option value="low">Low</option>
            <option value="medium">Medium</option>
            <option value="high">High</option>
          </select>
        </div>
    
        {/* Due Date */}
        <div>
          <label htmlFor="dueDate" className="block text-sm font-medium mb-1 text-gray-700">
            Due Date
          </label>
          <input
            type="date"
            id="dueDate"
            name="dueDate"
            value={Values.dueDate}
            onChange={change}
            className="w-full px-4 py-2 rounded-lg border border-gray-300 bg-pink-50 focus:outline-none focus:ring-2 focus:ring-pink-300"
          />
        </div>
    
        {/* Description */}
        <div>
          <label htmlFor="description" className="block text-sm font-medium mb-1 text-gray-700">
            Task Description
          </label>
          <textarea
            id="description"
            name="description"
            value={Values.description}
            onChange={change}
            placeholder="What is the task about?"
            className="w-full h-[120px] px-4 py-2 rounded-lg border border-gray-300 bg-pink-50 focus:outline-none focus:ring-2 focus:ring-pink-300"
            required
          />
        </div>
    
        {/* Buttons */}
        <div className="flex justify-between mt-4 gap-3">
          <button
            type="submit"
            className="flex-1 bg-blue-500 hover:bg-blue-600 text-white py-2 rounded-lg transition"
            onClick={(e) => editTask(e, Values._id)}
          >
            Save Changes
          </button>
    
          <button
            type="button"
            className="flex-1 bg-red-400 hover:bg-red-500 text-white py-2 rounded-lg transition"
            onClick={(e) => deleteTask(e, Values._id)}
          >
            Delete
          </button>
    
          <button
            type="button"
            className="flex-1 bg-gray-400 hover:bg-gray-500 text-white py-2 rounded-lg transition"
            onClick={() => setEditTaskDiv("hidden")}
          >
            Cancel
          </button>
        </div>
      </form>
    </div>
    );    
}

export default EditTask
