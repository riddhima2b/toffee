import React from "react";

const TaskCard = ({ data }) => {
  const showEditDiv = (e, id) => {
    e.preventDefault();
    window.sessionStorage.setItem("editTaskId", id);
    window.location.reload();
  };

  // Check for overdue tasks
  const isOverdue =
    data.dueDate && new Date(data.dueDate) < new Date(new Date().toDateString());

  // Priority-based background classes
  const getPriorityStyles = () => {
    switch (data.priority) {
      case "low":
        return "bg-green-50 border border-green-200";
      case "medium":
        return "bg-yellow-50 border border-yellow-200";
      case "high":
        return "bg-red-50 border border-red-200";
      default:
        return "bg-white";
    }
  };
  
  

  return (
    
    <button
      className={`rounded-xl px-4 w-full py-3 text-left transition-all duration-300 hover:shadow-md ${
        isOverdue ? "bg-red-100 border border-red-300" : getPriorityStyles()
      }`}
      onClick={(event) => showEditDiv(event, data._id)}
    >
    

      <div className="flex items-center justify-between">
        <h1 className="font-semibold text-gray-700">{data.title}</h1>
        <div
          className={`text-sm capitalize px-2 py-0.5 rounded-full font-medium ${
            data.priority === "low"
              ? "text-white bg-green-600"
              : data.priority === "medium"
              ? "text-white bg-yellow-400"
              : "text-white bg-red-600"}`}
        >
          {data.priority}
        </div>
      </div>

      <hr className="my-2" />

      <p className="text-sm text-zinc-600 mb-2">{data.description}</p>
      
      
      <p className="text-sm text-gray-500">
      Added on: {new Date(data.dateAdded).toLocaleDateString()}
      </p>
            
      {data.dueDate && (
        <div className="text-sm text-zinc-700">
          <span className="font-medium">Due:</span>{" "}
          <span className={isOverdue ? "text-red-600 font-semibold" : ""}>
            {new Date(data.dueDate).toLocaleDateString()}
          </span>
        </div>
      )}

      {isOverdue && (
        <p className="text-xs text-red-600 mt-1 font-medium">
          This task is overdue!
        </p>
      )}
    </button>
  );
};

export default TaskCard;
