import React from 'react';
import TaskCard from './TaskCard';

const YetToStart = ({tasks}) => {
  //console.log(task);
  return (
    <div className="flex flex-col gap-2.5">

      {tasks && 
      tasks.map((items,i)=>
      <TaskCard key={i} data={items}/>)}

    

      
    </div>
  )
}

export default YetToStart;
