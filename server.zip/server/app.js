const cookieParser = require("cookie-parser");
const cors = require("cors");
const dotenv = require("dotenv");
const express = require("express");
require("./connection/conn.js");
const userApis = require("./controllers/user.js");
const taskApis = require("./controllers/tasks.js");
const  userDet  = require("./controllers/user.js");
//const getTask1 = require("./controllers/users.js");
const authMiddleware = require("./middleware/authMiddleware"); // ✅ check the path


dotenv.config();

const app = express();
const PORT =3001;

// Middleware
app.use(express.json());
app.use(cors({
  origin: ["http://localhost:5173", "http://localhost:3001"],
  credentials: true,
}));
app.use(cookieParser());

// Routes
app.get("/", (req, res) => {
  res.send("Hello from backend");
});

app.use('/api/v1', userApis);
app.use('/api/v2',taskApis);

app.use('/api/v2',userDet);

//app.use('/api/v2',getTask1);
//Fix: Return actual tasks for frontend
/*app.get("/api/v2/getUserDetails", (req, res) => {
  res.json({tasks:{
     yetToStart:[],
     inProgress:[], 
    completed:[] },
  
});
});*/

// Start server
app.listen(PORT, () => {
  console.log(`Server started at port ${PORT}`);
});
