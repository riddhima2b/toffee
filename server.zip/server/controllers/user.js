const express = require("express");
const { login, logout, register, userDetails, getDeta } = require("../services/user.js");
const authMiddleware = require("../middleware/authMiddleware.js");
const router = express.Router();
//const getDet = require()



router.post("/register", register);
router.post("/login", login);
router.post("/logout", logout);

router.get("/getUserDetails",authMiddleware,userDetails);

//router.get("/getTask",authMiddleware,userDetails);
module.exports = router;
