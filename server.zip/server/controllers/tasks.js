const authMiddleware = require("../middleware/authMiddleware");
const { addTask, deleteTask, editTask, getTask } = require("../services/tasks");

//const authMiddleware1 = authMiddleware;
const router = require("express").Router();

router.post("/addTask", authMiddleware, addTask);
router.get("/getTask/:id", authMiddleware, getTask);
router.put("/editTask/:id", authMiddleware, editTask);
router.delete("/deleteTask/:id", authMiddleware, deleteTask);

module.exports = router;
