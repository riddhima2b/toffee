const mongoose =require ("mongoose");
const conn = async() => {

    try{
        await mongoose.connect("mongodb+srv://toffer1:loofah90@cluster0.jkrcrch.mongodb.net/Toffee1;"
        );
        console.log("connected to database");
    }
    catch(error)
    {
        //console.log(error);
        console.log("Not connected");
    }
    

}

conn();