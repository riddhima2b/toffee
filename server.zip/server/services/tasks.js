const Task = require("../models/tasks.js");

// Add Task
const addTask = async (req, res) => {
    try {
        const { title, description, priority, status } = req.body;
        const  {user}  = req;
        console.log(user);

        if (!title || !description) {
            return res.status(400).json({ error: "All fields are required." });
        }

        // Optional validation (commented out in original)
        
        if (title.length < 6) {
            return res.status(400).json({ error: "Title must have 6 characters" });
        }

        if (description.length < 6) {
            return res.status(400).json({ error: "Description must have 6 characters" });
        }
        

        const newTask = new Task({ title, description, priority, status });
        await newTask.save();

        user.tasks.push(newTask._id);
        await user.save();
        console.log(Task);
        return res.status(200).json({ success: "Task added!" });
    } catch (error) {
        return res.status(500).json({ error: "Internal server error" });
    }
};

// Edit Task
const editTask = async (req, res) => {
    try {
        const { id } = req.params;
        const { title, description, priority, status } = req.body;

        if (!title || !description) {
            return res.status(400).json({ error: "All fields are required." });
        }

        if (title.length < 6) {
            return res.status(400).json({ error: "Title must have 6 characters" });
        }

        if (description.length < 6) {
            return res.status(400).json({ error: "Description must have 6 characters" });
        }

        await Task.findByIdAndUpdate(id, { title, description, priority, status });
        return res.status(200).json({ success: "Task updated!" });
    } catch (error) {
        return res.status(500).json({ error: "Internal server error" });
    }
};

// Get Task
const getTask = async (req, res) => {
    try {
        const { id } = req.params;
        const taskDetails = await Task.findById(id);
        return res.status(200).json({ taskDetails });
    } catch (error) {
        return res.status(500).json({ error: "Internal server error" });
    }
};

// Delete Task
const deleteTask = async (req, res) => {
    try {
        const { id } = req.params;
        await Task.findByIdAndDelete(id);
        return res.status(200).json({ success: "Task Deleted!" });
    } catch (error) {
        return res.status(500).json({ error: "Internal server error" });
    }
};

module.exports = { addTask, deleteTask, editTask, getTask };
