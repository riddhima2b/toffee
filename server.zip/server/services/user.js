const bcrypt = require("bcryptjs");
const dotenv = require("dotenv");
const jwt = require("jsonwebtoken");
const User = require("../models/users.js");

dotenv.config();
const JWT_SECRET = process.env.JWT_SECRET;

const register = async (req, res) => {
    try {
        const { username, email, password } = req.body;

        if (!username || !email || !password) {
            return res.status(400).json({ error: "All fields are required!" });
        }

        const checkUser = await User.findOne({ $or: [{ email }, { username }] });
        if (checkUser) {
            return res.status(400).json({ error: "Email or Username already exists!" });
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        const newUser = new User({ username, email, password: hashedPassword });
        await newUser.save();

        return res.status(201).json({ success: "Registration successful!" });
    } catch (error) {
        console.error("Error in register function:", error.message);
        return res.status(500).json({ error: "Internal Server Error!" });
    }
};

const login = async (req, res) => {
    try {
        const { email, password } = req.body;

        if (!email || !password) {
            return res.status(400).json({ error: "All fields are required!" });
        }

        const checkUser = await User.findOne({ email });
        if (!checkUser) {
            return res.status(400).json({ error: "Invalid email or password!" });
            
        }

        const isMatch = await bcrypt.compare(password, checkUser.password);
        if (!isMatch) {
            return res.status(400).json({ error: "Invalid email or password!" });
        }

        const token = jwt.sign(
            { id: checkUser._id, email: checkUser.email },
            JWT_SECRET,
            { expiresIn: "30d" }
        );

        res.cookie("mp2tof", token, {
            httpOnly: true,
            secure: process.env.NODE_ENV === "production",
            sameSite: process.env.NODE_ENV === "production" ? "None" : "Lax",
            maxAge: 30 * 24 * 60 * 60 * 1000, // 30 days
        });

        return res.status(201).json({ success: "Login successful!", token });

    } catch (error) {
        console.error("Error in login function:", error.message);
        return res.status(400).json({ error: "Internal server error!" });
    }
};

const logout = async (req, res) => {
    try {
        res.clearCookie("mp2tof", {
            httpOnly: true,
        });

        res.json({ message: "Logged out" });
    } catch (error) {
        return res.status(404).json({ error: "Internal server error!" });
    }
};

const userDetails = async (req, res) => {
    try {
        const  user  = req.user;
        //console.log(user,'check requser duplicate user.js');
        const getDetails = await User.findById(user._id)
            .populate("tasks")
            .select("-password");
        //console.log()

        if(!getDetails){console.log("empty");}
        if (getDetails) {
            //console.log(getDetails,"details aai?");
            const allTasks = getDetails.tasks;
            let yetToStart = [];
            let inProgress = [];
            let completed = [];

           
            
            allTasks.map((item) => {
                console.log(item.status);
                //console.log(tasks.status);
                if (item.status =="yetToStart") {
                    console.log(item.status);
                    yetToStart.push(item);
                    console.log(item.status);
                } else if (item.status == "inProgress") {
                    inProgress.push(item);
                    console.log(item.status);
                } else {
                    completed.push(item); // ✅ fix: variable should be 'Completed', not 'completed'
                }console.log(item.status);
            });

            return res.status(200).json({
                success: "success",
                
                tasks: {yetToStart, inProgress ,completed} ,
            });}
            
        
    } catch (error) {
        return res.status(404).json({ error: "Internal server error" });
    }
};

module.exports = { login, logout, register, userDetails };
