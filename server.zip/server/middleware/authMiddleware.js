const dotenv = require("dotenv");
const jwt = require("jsonwebtoken");
const User = require("../models/users.js");

dotenv.config();
//const JWT_SECRET = process.env.JWT_SECRET;

const authMiddleware = async (req, res, next) => {
    console.log(req.headers);
    let token = "";

    // 👉 Also check Authorization header if token is not in cookies
    /*if(req.header.authorization?.startsWith("Bearer ")) {*/
        token = req.headers.authorization.split(" ")[1];
        //console.log(token);
    

    try {
        if (!token) {
            return res.status(401).json({ error: "Unauthorized: No token provided" });
        }

        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        const user = await User.findById(decoded.id);
        //console.log(user,'------------------'); //user,
        if (!user) {
            return res.status(404).json({ error: "User not found" });
        }

        req.user = user;
        //console.log(req.user,'check requser');
        console.log("this prints if no error");
        next();
    } catch (error) {
        console.error("❌ Error in authMiddleware:", error);
        return res.status(401).json({ error: "Invalid token" });
    }
};

module.exports = authMiddleware;
